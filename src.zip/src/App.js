import React from "react";
import "./App.css";
import "./css/landingPage.css";
import NavigationBar from "./components/NavigationBar.js";
import Intro from "./components/intro.js";

function App() {
  return (
    <div className="myBG">
      <NavigationBar />
      <Intro />
    </div>
  );
}

export default App;
